import model.Customer;
import model.Loan;
import model.LoanApplication;

public class Admin {
	/**
	 * constructor
	 */
	public Admin() {

	}

	/**
	 * approve a loan application
	 */
	public void approveLoan(LoanApplication loanApplication) {

	}

	/**
	 * terminate loan for customer.
	 */
	public void terminateLoan(Loan loan) {

	}

	/**
	 * generate a credit grading for customer.
	 */
	public void generateCreditGrading(Customer customer) {

	}

	/**
	 * can impose penalty fee on specific loans
	 */
	public void imposePenaltyFee(Loan loan) {

	}
}
