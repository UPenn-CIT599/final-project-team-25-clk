package eventobject;
import java.util.EventListener;


public interface LoanSelectionListener extends EventListener {
	public void loanSelectionOccured();
}